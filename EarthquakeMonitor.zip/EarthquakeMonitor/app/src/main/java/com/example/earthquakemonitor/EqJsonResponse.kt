package com.example.earthquakemonitor

class EqJsonResponse(features: List<Feature>) {
}