package com.example.earthquakemonitor

import java.util.*

class Feature(val id: String, val properties: Properties, val geometry: Geometry) {
}